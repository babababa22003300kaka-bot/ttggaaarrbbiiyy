#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🧠 Core Functions & Utilities
الدوال الأساسية ومدراء النظام
✅ نسخة كاملة مع الإضافة الفورية للـ pending.json
✅ مع دعم Taken Handler System
"""

import asyncio
import json
import logging
import random
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from api_manager import smart_cache
from config import (
    BURST_MODE_INTERVAL,
    FINAL_STATUSES,
    MONITORED_ACCOUNTS_FILE,
    POLLING_INTERVALS,
    STATUS_DESCRIPTIONS_AR,
    STATUS_EMOJIS,
    TRANSITIONAL_STATUSES,
)

# 🆕 استيراد Taken Handler
from sheets.taken import add_to_taken_queue
from stats import stats

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# 🔧 Load CONFIG once at startup (Performance Optimization)
# ═══════════════════════════════════════════════════════════════

with open("config.json", "r", encoding="utf-8") as f:
    CONFIG = json.load(f)


# ═══════════════════════════════════════════════════════════════
# 🧹 Cleanup Configuration
# ═══════════════════════════════════════════════════════════════

CLEANUP_INTERVAL = 21600  # 6 ساعات بالثواني
CLEANUP_AGE_HOURS = 50  # حذف الحسابات الأقدم من 50 ساعة
CLEANUP_THRESHOLD = 5  # الحد الأدنى للتنفيذ


# ═══════════════════════════════════════════════════════════════
# 💾 Database Functions with ID Validation + Source Tracking
# ═══════════════════════════════════════════════════════════════


def load_monitored_accounts() -> Dict:
    """تحميل الحسابات المراقبة"""
    if Path(MONITORED_ACCOUNTS_FILE).exists():
        try:
            with open(MONITORED_ACCOUNTS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {}


def save_monitored_accounts(accounts: Dict):
    """حفظ الحسابات المراقبة"""
    try:
        with open(MONITORED_ACCOUNTS_FILE, "w", encoding="utf-8") as f:
            json.dump(accounts, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"❌ Save error: {e}")


def add_monitored_account(
    email: str,
    account_id: str,
    status: str,
    chat_id: int,
    source: str = "manual",  # 🆕 NEW PARAMETER
):
    """
    🎯 إضافة حساب للمراقبة مع تخزين الـ ID الموثوق + المصدر
    """
    accounts = load_monitored_accounts()

    # استخدام الـ ID كـ key رئيسي (أكثر أماناً من الإيميل)
    key = f"{account_id}_{email}"

    accounts[key] = {
        "email": email,
        "account_id": account_id,
        "last_known_status": status,
        "chat_id": chat_id,
        "source": source,  # 🆕 تتبع المصدر
        "added_at": datetime.now().isoformat(),
        "last_check": datetime.now().isoformat(),
    }
    save_monitored_accounts(accounts)

    source_label = "البوت 🤖" if source == "bot" else "يدوي 👤"
    logger.info(
        f"✅ Account added to monitoring: {email} (ID: {account_id}, Source: {source_label})"
    )


def update_monitored_account_status(account_id: str, new_status: str):
    """
    🎯 تحديث الحالة باستخدام الـ ID
    """
    accounts = load_monitored_accounts()

    # البحث بالـ ID
    for key, data in accounts.items():
        if data.get("account_id") == account_id:
            data["last_known_status"] = new_status
            data["last_check"] = datetime.now().isoformat()
            save_monitored_accounts(accounts)
            return

    logger.warning(f"⚠️ Account ID {account_id} not found in monitoring list")


# ═══════════════════════════════════════════════════════════════
# 🛡️ Helper Functions
# ═══════════════════════════════════════════════════════════════


def is_admin(user_id: int, admin_ids: list) -> bool:
    """التحقق من صلاحيات الأدمن"""
    return not admin_ids or user_id in admin_ids


def get_adaptive_interval(status: str) -> float:
    """الحصول على فاصل زمني ذكي"""
    interval_range = POLLING_INTERVALS.get(status.upper(), POLLING_INTERVALS["DEFAULT"])
    return round(random.uniform(*interval_range), 2)


def format_number(value) -> str:
    """تنسيق الأرقام"""
    if value is None or value == "" or value == "null":
        return "0"

    try:
        value_str = str(value).strip()
        if not value_str.replace(".", "", 1).replace("-", "", 1).isdigit():
            return value_str

        num = float(value_str)

        if abs(num) < 1000:
            return str(int(num)) if num == int(num) else str(num)

        k_value = num / 1000

        if abs(k_value) >= 1000:
            return f"{k_value:,.0f}k"
        else:
            return f"{int(k_value)}k"
    except:
        return str(value)


def get_status_emoji(status: str) -> str:
    """الحصول على emoji للحالة"""
    return STATUS_EMOJIS.get(status.upper(), "📊")


def get_status_description_ar(status: str) -> str:
    """الحصول على الوصف العربي للحالة"""
    return STATUS_DESCRIPTIONS_AR.get(status.upper(), status)


def parse_sender_data(text: str) -> Dict:
    """
    تحليل بيانات السيندر من النص (نسخة مصححة 100%)

    ✅ يدعم:
    - اسحب / اسحبي / يسحب / اسحبو / اسحبوا
    - يسيب / سيب / سيبي / سيبو / اسيب / سيبوا
    - مع أو بدون مسافات
    - أرقام عربية وإنجليزية
    - الباسورد لو فيه أرقام مش هياخده كـ Code
    - إزالة الأكواد المكررة
    """
    lines = text.strip().split("\n")
    data = {
        "email": "",
        "password": "",
        "codes": "",
        "amount_take": "",
        "amount_keep": "",
    }

    # ✅ محسّن: يدعم أرقام عربية في الإيميل (نادر بس ممكن)
    email_pattern = r"[a-zA-Z0-9٠-٩._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"

    # 🧠 الكلمات الذكية للسحب والإبقاء
    TAKE_KEYWORDS = [
        "اسحب",
        "اسحبي",
        "اسحبو",
        "اسحبوا",
        "يسحب",
        "يسحبوا",
        "خذ",
        "خدي",
        "خدو",
        "take",
    ]

    KEEP_KEYWORDS = [
        "يسيب",
        "سيب",
        "سيبي",
        "سيبو",
        "سيبوا",
        "اسيب",
        "اسيبي",
        "اسيبو",
        "خلي",
        "خليي",
        "خليو",
        "ابقي",
        "ابقى",
        "keep",
    ]

    potential_code_text = ""
    password_found = False
    lines_to_skip = set()

    # ════════════════════════════════════════════════════════
    # 1️⃣ المرحلة الأولى: نجيب الإيميل والباسورد
    # ════════════════════════════════════════════════════════
    for idx, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue

        # ✅ البحث عن الإيميل
        if re.match(email_pattern, line):
            data["email"] = line.lower()
            lines_to_skip.add(idx)
            continue

        # ✅ استخلاص الباسورد (أول سطر بعد الإيميل)
        if data["email"] and not password_found:
            data["password"] = line
            password_found = True
            lines_to_skip.add(idx)
            continue

    # ════════════════════════════════════════════════════════
    # 2️⃣ المرحلة الثانية: نجيب الأوامر والأكواد من باقي السطور
    # ════════════════════════════════════════════════════════
    for idx, line in enumerate(lines):
        line = line.strip()
        if not line or idx in lines_to_skip:
            continue

        # 🧠 البحث الذكي عن أمر السحب
        if not data["amount_take"]:
            take_found = extract_amount_smart(line, TAKE_KEYWORDS)
            if take_found:
                data["amount_take"] = take_found

        # 🧠 البحث الذكي عن أمر الإبقاء
        if not data["amount_keep"]:
            keep_found = extract_amount_smart(line, KEEP_KEYWORDS)
            if keep_found:
                data["amount_keep"] = keep_found

        # ✅ جمع باقي النص للبحث عن الأكواد
        line_for_codes = remove_commands(line, TAKE_KEYWORDS + KEEP_KEYWORDS)
        if line_for_codes:
            potential_code_text += line_for_codes + " "

    # ════════════════════════════════════════════════════════
    # 3️⃣ المرحلة الثالثة: استخلاص الأكواد النهائية
    # ════════════════════════════════════════════════════════
    found_codes = re.findall(r"\d{8,}", potential_code_text)
    cleaned_codes = [code[-8:] for code in found_codes]
    # ✅ محسّن: شيل الأكواد المكررة مع الحفاظ على الترتيب
    unique_codes = list(dict.fromkeys(cleaned_codes))
    data["codes"] = ",".join(unique_codes)

    return data


def extract_amount_smart(line: str, keywords: List[str]) -> str:
    """
    🧠 استخلاص ذكي للمبلغ من السطر
    """
    # تحويل الأرقام العربية
    line_normalized = convert_arabic_numbers(line.lower())

    # البحث عن الكلمة المفتاحية + الرقم
    for keyword in keywords:
        pattern = rf"{keyword}\s*(\d+)"
        match = re.search(pattern, line_normalized)
        if match:
            return match.group(1)

    return ""


def remove_commands(line: str, keywords: List[str]) -> str:
    """
    🧹 إزالة الأوامر من السطر قبل البحث عن الأكواد
    """
    # ✅ مصحح: نحول الأرقام العربية أولاً
    line_cleaned = convert_arabic_numbers(line)

    for keyword in keywords:
        pattern = rf"{keyword}\s*\d+"
        line_cleaned = re.sub(pattern, "", line_cleaned, flags=re.IGNORECASE)

    return line_cleaned.strip()


def convert_arabic_numbers(text: str) -> str:
    """
    تحويل الأرقام العربية (٠-٩) إلى إنجليزية (0-9)
    """
    arabic_to_english = {
        "٠": "0",
        "١": "1",
        "٢": "2",
        "٣": "3",
        "٤": "4",
        "٥": "5",
        "٦": "6",
        "٧": "7",
        "٨": "8",
        "٩": "9",
    }

    processed_text = text
    for ar, en in arabic_to_english.items():
        processed_text = processed_text.replace(ar, en)

    return processed_text


# ═══════════════════════════════════════════════════════════════
# 🆕 Queue Management for Google Sheets (IMMEDIATE ADDITION)
# ═══════════════════════════════════════════════════════════════


def add_to_pending_queue_immediately(email: str, account_id: str):
    """
    🆕 إضافة فورية للإيميل والID في pending.json (بدون انتظار)
    تستخدم عند اكتشاف الـ ID مباشرة
    """
    pending_file = Path("data/pending.json")
    pending_file.parent.mkdir(exist_ok=True)

    # تحميل البيانات الحالية
    if pending_file.exists():
        try:
            with open(pending_file, "r", encoding="utf-8") as f:
                data = json.load(f)
        except:
            data = {"emails": []}
    else:
        data = {"emails": []}

    # إضافة الإيميل والـ ID فوراً
    data["emails"].append(
        {"email": email, "id": account_id, "added_at": datetime.now().isoformat()}
    )

    # حفظ
    with open(pending_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    logger.info(f"📝 Added {email} (ID: {account_id}) to pending queue IMMEDIATELY")


def add_to_pending_queue(email: str):
    """
    دالة للتوافق مع Web API - تضيف بدون ID
    """
    pending_file = Path("data/pending.json")
    pending_file.parent.mkdir(exist_ok=True)

    # تحميل البيانات الحالية
    if pending_file.exists():
        try:
            with open(pending_file, "r", encoding="utf-8") as f:
                data = json.load(f)
        except:
            data = {"emails": []}
    else:
        data = {"emails": []}

    # إضافة الإيميل بدون ID
    data["emails"].append(
        {
            "email": email,
            "id": "N/A",  # سيتم تحديثه لاحقاً
            "added_at": datetime.now().isoformat(),
        }
    )

    # حفظ
    with open(pending_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    logger.info(f"📝 Added {email} to pending queue (via API)")


# ═══════════════════════════════════════════════════════════════
# 🚀 Burst Mode Initial Monitoring + Source Tracking
# ═══════════════════════════════════════════════════════════════


async def wait_for_status_change(
    api_manager,
    email: str,
    message_obj,
    chat_id: int,
    default_group_name: str,  # 🆕 NEW PARAMETER
) -> Tuple[bool, Optional[Dict]]:
    """
    🚀 مراقبة مع Burst Mode المؤقت + تحديد المصدر

    عند إضافة حساب جديد:
    1. تفعيل Burst Mode (تحديث cache كل 2.5 ثانية)
    2. 🆕 إضافة فورية لـ pending.json عند اكتشاف ID
    3. مراقبة سريعة جداً للحساب الجديد
    4. إضافة للمراقبة فقط لو: AVAILABLE + جروب مطابق
    """

    global stats

    await asyncio.sleep(3.0)

    start_time = datetime.now()
    total_elapsed = 0
    last_status = None
    status_changes = []
    stable_count = 0
    account_id = None

    # 🚀 الخطوة 1: جلب الحساب لأول مرة والحصول على الـ ID
    logger.info(f"🔍 Looking for new account: {email}")

    for initial_attempt in range(1, 15):  # 15 محاولة = ~45 ثانية
        account_info = await api_manager.search_sender_by_email(email)

        if account_info:
            account_id = account_info.get("idAccount")
            if account_id:
                logger.info(f"✅ Found account: {email} (ID: {account_id})")

                # 🚀 تفعيل Burst Mode لهذا الحساب
                smart_cache.activate_burst_mode(account_id)

                # 🆕 إضافة فورية للـ pending.json (نفس اللحظة)
                add_to_pending_queue_immediately(email, account_id)

                break

        await message_obj.edit_text(
            f"🔍 *البحث الأولي عن الحساب*\n\n"
            f"📧 `{email}`\n"
            f"🔄 المحاولة: {initial_attempt}/15\n"
            f"⏱️ ~{total_elapsed:.0f}s",
            parse_mode="Markdown",
        )

        interval = 3.0
        total_elapsed += interval
        await asyncio.sleep(interval)

    if not account_id:
        return False, None

    # 🚀 الخطوة 2: مراقبة سريعة مع Burst Mode
    logger.info(f"🚀 Starting burst monitoring for {email} (ID: {account_id})")

    max_attempts = 40  # 40 محاولة * 2.5 ثانية = 100 ثانية max

    for attempt in range(1, max_attempts + 1):
        try:
            # ✅ تحديث مؤشر الـ Burst ليعرض العدد الفعلي للحسابات النشطة
            mode_indicator = (
                f"🚀 BURST ({len(smart_cache.burst_targets)})"
                if smart_cache.burst_targets
                else "🔄 NORMAL"
            )

            # 🎯 البحث بالـ ID (أكثر أماناً)
            account_info = await api_manager.search_sender_by_id(account_id)

            if not account_info:
                logger.warning(f"⚠️ Account ID {account_id} disappeared!")
                await asyncio.sleep(2.0)
                continue

            status = account_info.get("Status", "غير محدد").upper()

            # تتبع التغييرات
            if status != last_status:
                change_time = (datetime.now() - start_time).total_seconds()
                logger.info(f"📊 {email} status: {status} ({change_time:.1f}s)")

                status_changes.append(
                    {"status": status, "time": datetime.now(), "elapsed": total_elapsed}
                )

                if last_status and status in FINAL_STATUSES:
                    stats.fast_detections += 1
                    logger.info(
                        f"⚡ FAST: {last_status} → {status} in {change_time:.1f}s"
                    )

                last_status = status
                stable_count = 0
            else:
                stable_count += 1

            # تحديد نوع الحالة
            is_final = status in FINAL_STATUSES
            is_transitional = status in TRANSITIONAL_STATUSES

            status_ar = get_status_description_ar(status)
            status_type = (
                "✅ نهائية"
                if is_final
                else "⏳ انتقالية" if is_transitional else "❓ غير محددة"
            )

            # عرض سجل التغييرات
            changes_text = ""
            if len(status_changes) > 1:
                changes_text = "\n📝 *التغييرات:*\n"
                for i, change in enumerate(status_changes[-3:]):
                    changes_text += (
                        f"   {i+1}. `{change['status']}` ({change['elapsed']:.0f}s)\n"
                    )

            # رسالة التحديث
            await message_obj.edit_text(
                f"{mode_indicator} *مراقبة ذكية*\n\n"
                f"📧 `{email}`\n"
                f"🆔 ID: `{account_id}`\n"
                f"📊 *تمت الإضافة لـ Google Sheets*\n\n"
                f"📊 *الحالة:* `{status}`\n"
                f"   {get_status_emoji(status)} {status_ar}\n\n"
                f"🎯 النوع: {status_type}\n"
                f"🔄 الاستقرار: {stable_count}/2\n"
                f"{changes_text}\n"
                f"⏱️ الوقت: {int(total_elapsed)}s\n"
                f"🔍 المحاولة: {attempt}/{max_attempts}",
                parse_mode="Markdown",
            )

            # 🆕 منطق التوقف + شرط الإضافة المحدّث
            if is_final:
                response_time = (datetime.now() - start_time).total_seconds()
                logger.info(f"✅ {email} STABLE at {status} in {response_time:.1f}s")

                # 🆕 إضافة للمراقبة: AVAILABLE أو REFRESHING أو TRANSFERRING + جروب مطابق
                added_to_monitor = False

                # قائمة الحالات المراقبة
                monitored_statuses = ["AVAILABLE", "REFRESHING", "TRANSFERRING"]

                if status in monitored_statuses:
                    group_name = account_info.get("Group", "")
                    if group_name == default_group_name:  # ← مطابقة دقيقة
                        add_monitored_account(
                            email,
                            account_id,
                            status,
                            chat_id,
                            source="bot",  # 🆕 من البوت
                        )
                        added_to_monitor = True
                        logger.info(f"✅ Added {email} to monitoring ({status})")

                # ✅ الحل النهائي: إرسال إشعار بالحالة النهائية قبل الخروج
                await send_status_notification(
                    message_obj._bot,     
                    email,
                    account_id,
                    last_status or "UNKNOWN",
                    status,
                    chat_id,
                    account_info,
                    "bot",
                )

                # ✅ الحل الصحيح: إزالة الحساب الحالي فقط من قائمة الأهداف
                smart_cache.deactivate_burst_target(account_id)

                return True, account_info

            # ✅ فاصل زمني ذكي يعتمد على قائمة الأهداف
            if smart_cache.burst_targets:
                interval = BURST_MODE_INTERVAL
            else:
                interval = 4.0 if is_transitional else 5.0

            total_elapsed += interval
            await asyncio.sleep(interval)

        except Exception as e:
            logger.exception(f"❌ Monitoring error #{attempt}: {e}")
            await asyncio.sleep(2.0)
            total_elapsed += 2.0

    # انتهت المحاولات
    logger.warning(f"⏱️ {email}: Timeout, final status: {last_status}")

    # ✅ الحل الصحيح: إزالة الحساب الحالي فقط من قائمة الأهداف
    if account_id:
        smart_cache.deactivate_burst_target(account_id)

    # 🆕 شرط الإضافة المحدّث (يدعم 3 حالات)
    if account_info:
        status = account_info.get("Status", "").upper()
        monitored_statuses = ["AVAILABLE", "REFRESHING", "TRANSFERRING"]

        if status in monitored_statuses:
            group_name = account_info.get("Group", "")
            if group_name == default_group_name:
                add_monitored_account(email, account_id, status, chat_id, source="bot")
                logger.info(f"✅ Added {email} to monitoring (timeout case, {status})")
        return True, account_info

    return False, None


# ═══════════════════════════════════════════════════════════════
# 🎯 Smart Notification Groups System
# ═══════════════════════════════════════════════════════════════


def parse_group_id(value):
    """
    استخراج ID من أي تنسيق

    Examples:
        -5088596401 → -5088596401
        "🪪 The ID of متاح is: -5088596401" → -5088596401
    """
    if isinstance(value, int):
        return value

    if isinstance(value, str):
        # البحث عن أول رقم (سالب أو موجب)
        match = re.search(r"-?\d+", value)
        if match:
            return int(match.group())

    raise ValueError(f"❌ Invalid group_id: {value}")


def find_target_group(new_status: str, config: dict) -> Optional[int]:
    """
    🎯 إيجاد الجروب المناسب للحالة الجديدة

    Logic:
    1. ابحث في الجروبات المخصصة (statuses غير فاضية)
    2. لو لقيت تطابق → أرجع group_id
    3. لو مفيش تطابق → Fallback (statuses فاضية)

    Returns:
        int: group_id للإرسال إليه
        None: لو النظام معطل أو مفيش Fallback
    """
    # 1. التحقق من التفعيل العام
    notification_groups = config.get("notification_groups", {})
    if not notification_groups.get("enabled", False):
        logger.info("📵 Notification groups system is disabled")
        return None

    # 2. تنظيف الحالة
    normalized_status = new_status.strip().upper()

    # 3. البحث في الجروبات المخصصة
    groups = notification_groups.get("groups", [])
    fallback_group = None

    for group in groups:
        if not group.get("enabled", True):
            continue  # جروب معطل

        # تنظيف الحالات المخزنة
        group_statuses = [s.strip().upper() for s in group.get("statuses", [])]

        # هل ده Fallback group؟
        if not group_statuses:
            fallback_group = group
            continue

        # تطابق؟
        if normalized_status in group_statuses:
            group_id = parse_group_id(group.get("group_id"))
            logger.info(
                f"✅ Status '{new_status}' → Group '{group.get('name')}' ({group_id})"
            )
            return group_id

    # 4. Fallback: لو مفيش تطابق
    if fallback_group:
        group_id = parse_group_id(fallback_group.get("group_id"))
        logger.info(
            f"🔄 Status '{new_status}' → Fallback Group '{fallback_group.get('name')}' ({group_id})"
        )
        return group_id

    # 5. مفيش Fallback (مشكلة خطيرة!)
    logger.warning(f"⚠️ No fallback group found! Status '{new_status}' will be skipped!")
    return None


def validate_notification_config(config: dict):
    """
    🛡️ التحقق من صحة إعدادات الإشعارات عند البدء

    Checks:
    1. وجود Fallback group مفعّل (statuses فاضية)
    2. صحة group_ids
    """
    notification_groups = config.get("notification_groups", {})

    if not notification_groups:
        logger.warning("⚠️ No 'notification_groups' section in config.json")
        return

    groups = notification_groups.get("groups", [])

    # 1. التحقق من وجود Fallback
    has_fallback = False
    for group in groups:
        if not group.get("statuses") and group.get("enabled", True):
            has_fallback = True
            logger.info(f"✅ Fallback group found: '{group.get('name')}'")
            break

    if not has_fallback:
        logger.error("❌ CRITICAL: No enabled fallback group (empty statuses list)!")
        logger.error("❌ Please add a group with 'statuses': [] and 'enabled': true")
        raise ValueError("⚠️ Missing mandatory fallback group!")

    # 2. التحقق من IDs
    for group in groups:
        try:
            group_id = parse_group_id(group.get("group_id"))
            logger.debug(f"✅ Group '{group.get('name')}': ID = {group_id}")
        except Exception as e:
            logger.error(f"❌ Invalid group_id for '{group.get('name')}': {e}")
            raise

    logger.info("✅ Notification config validation passed!")


# ═══════════════════════════════════════════════════════════════
# 📧 Notification Function with Source Display
# ═══════════════════════════════════════════════════════════════


async def send_status_notification(
    telegram_bot,
    email: str,
    account_id: str,
    old_status: str,
    new_status: str,
    chat_id: int,  # محفوظ للتوافق، لكن لن يتم استخدامه مباشرة
    account_data: Dict,
    source: str = "manual",
):
    """
    ✅ إرسال إشعار تغيير الحالة إلى الجروب المناسب

    🎯 Smart Routing:
    - يختار الجروب المناسب حسب الحالة الجديدة
    - يرسل لجروب واحد فقط (Exclusivity)
    - يستخدم Fallback لو مفيش تطابق

    ⚡ Performance:
    - يستخدم CONFIG المُحمَّل مسبقاً (مرة واحدة عند البدء)
    - مفيش file I/O متكرر
    """
    try:
        # 🎯 الخطوة 1: إيجاد الجروب المناسب باستخدام النظام الجديد
        # نحن نستخدم المتغير العالمي CONFIG الذي تم تحميله في بداية الملف
        target_group_id = find_target_group(new_status, CONFIG)

        # 🎯 الخطوة 2: التحقق مما إذا كان هناك جروب مستهدف
        if target_group_id is None:
            logger.info(
                f"ℹ️ Skip notification for {email}: No target group found or system disabled."
            )
            return

        # 🎯 الخطوة 3: تجهيز الرسالة (هذا الجزء سليم ولا يحتاج تعديل)
        old_emoji = get_status_emoji(old_status)
        new_emoji = get_status_emoji(new_status)
        old_status_ar = get_status_description_ar(old_status)
        new_status_ar = get_status_description_ar(new_status)
        source_line = "🤖 المصدر: من البوت" if source == "bot" else "👤 المصدر: يدوي"

        notification = (
            f"🔔 *تنبيه تغيير الحالة!*\n\n"
            f"📧 `{email}`\n"
            f"{source_line}\n"
            f"🆔 ID: `{account_id}`\n\n"
            f"📊 *الحالة السابقة:*\n"
            f"   `{old_status}`\n"
            f"   {old_emoji} {old_status_ar}\n\n"
            f"📊 *الحالة الجديدة:*\n"
            f"   `{new_status}`\n"
            f"   {new_emoji} {new_status_ar}\n\n"
            f"🕐 الوقت: {datetime.now().strftime('%H:%M:%S')}\n"
        )

        available = format_number(account_data.get("Available", "0"))
        taken = format_number(account_data.get("Taken", "0"))

        if available != "0" or taken != "0":
            notification += f"\n💵 المتاح: {available}\n✅ المسحوب: {taken}\n"

        notification += f"\n💡 `/search {email}` للتفاصيل"

        # 🎯 الخطوة 4: إرسال الإشعار إلى الجروب الصحيح
        await telegram_bot.send_message(
            chat_id=target_group_id,  # ⬅️ الأهم: استخدام المتغير الجديد هنا
            text=notification,
            parse_mode="Markdown",
        )

        logger.info(
            f"✅ Notification sent to group {target_group_id} for status '{new_status}'"
        )

    except Exception as e:
        logger.error(f"❌ Failed to send notification: {e}")


# ═══════════════════════════════════════════════════════════════
# 🧹 Cleanup Function
# ═══════════════════════════════════════════════════════════════


def cleanup_old_accounts(accounts: Dict) -> int:
    """
    🧹 تنظيف الحسابات القديمة (>50 ساعة بدون تحديث)

    ✅ Lazy Timestamp Strategy:
    - الحسابات المهمة (AVAILABLE, REFRESHING, TRANSFERRING) → تفضل 50 ساعة
    - أي حالة تانية (WRONG DETAILS, ERROR, LOCKED, etc.) → تتمسح فوراً
    - Zero resources overhead
    - Flexible & Simple
    - Auto-removes future unknown statuses

    Returns:
        int: عدد الحسابات المحذوفة
    """
    if not accounts:
        return 0

    # ✅ الحالات المهمة اللي نخليها 50 ساعة
    KEEP_STATUSES = ["AVAILABLE", "REFRESHING", "TRANSFERRING"]

    try:
        now = datetime.now()
        cutoff_time = now - timedelta(hours=CLEANUP_AGE_HOURS)  # 50 ساعة

        # جمع مفاتيح الحسابات اللي هنحذفها
        old_keys = []

        for key, data in accounts.items():
            try:
                last_check_str = data.get("last_check")
                if not last_check_str:
                    continue

                last_check = datetime.fromisoformat(last_check_str)
                status = data.get("last_known_status", "")

                # ✅ القرار الذكي (Lazy Timestamp):
                # احذف لو: (الحساب أقدم من 50 ساعة) AND (حالته مش من المهمين)
                if last_check < cutoff_time and status not in KEEP_STATUSES:
                    old_keys.append(key)

            except (ValueError, TypeError, AttributeError):
                # لو في مشكلة في التاريخ، نتخطى الحساب ده
                continue

        # Early exit: لو مفيش حسابات كفاية للحذف
        if len(old_keys) < CLEANUP_THRESHOLD:
            return 0

        # حذف الحسابات (in-place)
        for key in old_keys:
            del accounts[key]

        # حفظ التغييرات
        if old_keys:
            save_monitored_accounts(accounts)

        logger.info(
            f"🧹 Cleanup: Deleted {len(old_keys)} old accounts (non-critical statuses)"
        )
        return len(old_keys)

    except Exception as e:
        logger.error(f"⚠️ Cleanup error: {e}")
        return 0


# ═══════════════════════════════════════════════════════════════
# 🔄 Background Monitor with Smart TTL + Auto-Discovery + Taken Handler
# ═══════════════════════════════════════════════════════════════


async def continuous_monitor(
    api_manager,
    telegram_bot,
    default_group_name: str,  # 🆕 NEW PARAMETER
    default_chat_id: Optional[int],  # 🆕 NEW PARAMETER
):
    """
    🎯 مراقب مستمر مع Smart TTL + Auto-Discovery + Taken Handler
    """

    logger.info(
        "🔄 Background monitor started (Smart TTL + Auto-Discovery + Taken Handler)"
    )

    while True:
        try:
            accounts = load_monitored_accounts()

            # Fetch all accounts
            all_accounts = await api_manager.fetch_all_accounts_batch()

            # Build ID dictionary
            accounts_by_id = {
                acc.get("idAccount"): acc
                for acc in all_accounts
                if acc.get("idAccount")
            }

            # 🆕 AUTO-DISCOVERY LOGIC
            existing_ids = {
                data.get("account_id")
                for data in accounts.values()
                if data.get("account_id")
            }

            auto_added = False
            # 🆕 قائمة الحالات المراقبة
            monitored_statuses = ["AVAILABLE", "REFRESHING", "TRANSFERRING"]

            for account in all_accounts:
                account_id = account.get("idAccount")
                account_status = account.get("Status", "").upper()

                # Skip if:
                # - No ID
                # - Already monitored
                # - Not in monitored statuses (AVAILABLE, REFRESHING, TRANSFERRING)
                # - Group doesn't match
                if (
                    not account_id
                    or account_id in existing_ids
                    or account_status not in monitored_statuses
                    or account.get("Group", "") != default_group_name  # 🎯 exact match
                ):
                    continue

                # Auto-add
                email = account.get("Sender", "")
                chat_id = default_chat_id or 0
                add_monitored_account(
                    email,
                    account_id,
                    account_status,
                    chat_id,
                    source="manual",  # 🆕 auto-discovered = manual
                )
                existing_ids.add(account_id)
                auto_added = True
                logger.info(
                    f"✅ Auto-monitored {email} ({account_status} + default group)"
                )

            # Reload if auto-added
            if auto_added:
                accounts = load_monitored_accounts()

            # Skip if no accounts
            if not accounts:
                await asyncio.sleep(30)
                continue

            changes_detected = 0

            for key, data in list(accounts.items()):
                try:
                    account_id = data.get("account_id")
                    if not account_id:
                        continue

                    # 🎯 البحث بالـ ID (أكثر أماناً من الإيميل)
                    account_info = accounts_by_id.get(account_id)

                    if not account_info:
                        logger.warning(f"⚠️ Account ID {account_id} not found in batch")
                        continue

                    current_status = account_info.get("Status", "غير محدد").upper()
                    last_status = data["last_known_status"].upper()

                    if current_status != last_status:
                        changes_detected += 1
                        email = data.get("email", "unknown")

                        logger.info(f"🔔 {email}: {last_status} → {current_status}")

                        # 🆕 كشف AMOUNT TAKEN و DISABLED
                        if current_status in ["AMOUNT TAKEN", "DISABLED"]:
                            taken_value = account_info.get("Taken", "0")

                            # التحقق من وجود قيمة صالحة
                            try:
                                if float(taken_value) > 0:
                                    logger.info(
                                        f"💸 {current_status} detected for {email}: {taken_value} coins"
                                    )

                                    # ✅ تنسيق الحالة بشكل صحيح
                                    status_normalized = current_status.replace(" ", "_")

                                    add_to_taken_queue(
                                        account_id,
                                        email,
                                        status_normalized,
                                        str(taken_value),
                                    )
                            except (ValueError, TypeError):
                                logger.warning(
                                    f"⚠️ Invalid Taken value for {email}: {taken_value}"
                                )

                        if current_status in ["BACKUP CODE WRONG", "WRONG DETAILS"]:
                            logger.warning(
                                f"⚠️ {email} needs attention: {current_status}"
                            )
                        elif current_status == "TRANSFER LIST IS FULL":
                            logger.info(f"📦 {email} transfer list full")

                        update_monitored_account_status(account_id, current_status)

                        # ✅ الحل النهائي: استدعاء دالة الإشعارات مرة واحدة فقط
                        await send_status_notification(
                            telegram_bot,
                            email,
                            account_id,
                            last_status,
                            current_status,
                            data["chat_id"],  # سيتم تجاهل هذا الرقم
                            account_info,
                            data.get("source", "manual"),
                        )
                    else:
                        update_monitored_account_status(account_id, current_status)

                except Exception as e:
                    logger.exception(f"❌ Error checking account")

            # 🎯 تعديل ذكي للـ TTL بناءً على النشاط
            smart_cache.adjust_ttl(changes_detected)

            # 🧹 Cleanup old accounts (every 6 hours)
            if not hasattr(cleanup_old_accounts, "last_run"):
                cleanup_old_accounts.last_run = datetime.now()

            time_since_cleanup = (
                datetime.now() - cleanup_old_accounts.last_run
            ).total_seconds()

            if time_since_cleanup >= CLEANUP_INTERVAL:
                removed_count = cleanup_old_accounts(accounts)
                if removed_count > 0:
                    logger.info(
                        f"🧹 Cleaned {removed_count} old accounts (>50h inactive)"
                    )
                cleanup_old_accounts.last_run = datetime.now()

            # فترة الانتظار
            statuses = [d["last_known_status"] for d in accounts.values()]

            if "LOGGING" in statuses:
                cycle_delay = random.uniform(10, 20)
            elif any(
                s in statuses
                for s in ["AVAILABLE", "ACTIVE", "REFRESHING", "TRANSFERRING"]
            ):
                cycle_delay = random.uniform(30, 60)
            else:
                cycle_delay = random.uniform(60, 120)

            logger.debug(
                f"💤 Next check in {cycle_delay:.1f}s (TTL={smart_cache.cache_ttl:.0f}s, changes={changes_detected})"
            )
            await asyncio.sleep(cycle_delay)

        except Exception as e:
            logger.exception("❌ Monitor error")
            await asyncio.sleep(30)
