#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🌐 Web API Module
"""

__version__ = "1.0.0"
